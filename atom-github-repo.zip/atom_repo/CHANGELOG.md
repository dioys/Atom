# Changelog

## 0.16.1
- Repo reorganised for GitHub (`src/`, `scripts/`, `tests/`, `assets/`, `docs/`); CI + release workflows; Dependabot.

## 0.16.0
- Cleanup (dead code, pixel-art, old test scripts). Installer (Inno Setup) and portable zip. Privacy policy.

## 0.15.x
- Folders (Work / Reports / About me), Hear and Screen buttons, screen picker, simpler code answers, last chat kept.

## 0.14.0
- Call helper (hears the call, suggests answers from your profile, summary and to-dos).
